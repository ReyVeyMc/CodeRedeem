# CodeRedeem

Sistem Redeem Code untuk **Paper 1.21.8 (kompatibel 1.21.x)** (Java 21). Standalone, tanpa dependensi plugin lain.
**Developer / Author: ReyVey**

## 1. Cara install
1. Build: `mvn clean package` → hasil `target/CodeRedeem-1.0.0.jar`
2. Salin jar ke folder `plugins/` server Paper 1.21.8 (kompatibel 1.21.x) (Java 21).
3. Start server. File `config.yml`, `messages.yml`, `codes.yml` dibuat otomatis di `plugins/CodeRedeem/`.

## 2. Cara membuat kode
```
/redeem create <kode> [max-use] [expired]
/redeem create WELCOME2026 100 2026-12-31 23:59:59
/redeem create EVENT 50 none
```
Nama kode: 3-32 karakter (huruf, angka, `_`, `-`), tidak case-sensitive. Kode baru belum punya hadiah
(tidak bisa di-redeem sampai hadiah ditambahkan). Pengaturan lain lewat `/redeem set`.

## 3. Cara mengatur expired
```
/redeem set <kode> expired 2026-12-31 23:59:59
/redeem set <kode> expired none        (permanent)
```
Format: `YYYY-MM-DD HH:mm:ss` (juga `YYYY-MM-DDTHH:mm:ss` atau `YYYY-MM-DD` = 23:59:59), zona waktu dari `settings.timezone`.
Jika kode auto-disabled karena expired lalu tanggalnya diperpanjang, kode aktif kembali otomatis.

## 4. Cara mengatur reward
```
/redeem reward <kode> addcmd give %player% diamond 10   (dijalankan console)
/redeem reward <kode> delcmd <nomor>
/redeem reward <kode> additem          (item di tangan: nama, lore, enchant, custom model data ikut tersimpan)
/redeem reward <kode> delitem <nomor>
/redeem reward <kode> adddisplay 50.000 Money   (teks hadiah yang dilihat player)
/redeem reward <kode> deldisplay <nomor>
```
Placeholder command: `%player%`, `%uuid%`, `%displayname%`. Command tidak pernah ditampilkan ke player;
yang tampil adalah teks *display* + daftar item.

## 5. Max uses
```
/redeem set <kode> max-uses 100     (-1 = unlimited)
/redeem set <kode> one-use true     (satu UUID hanya sekali)
```
Jika `uses` mencapai `max-uses` status menjadi **FULL**.

## 6. Melihat list / info
`/redeem list [halaman]` · `/redeem info <kode>`

## 7. Delete
`/redeem delete <kode>` lalu `/redeem delete <kode> confirm`

## 8. Reload
`/redeem reload` — memuat ulang config, messages, codes. Data penggunaan tersimpan di `codes.yml`, jadi tidak hilang.
Jika `codes.yml` rusak, data lama di memori tetap dipakai dan salinan file rusak disimpan sebagai `codes.yml.broken-<waktu>`.

## 9. Permission
| Permission | Default | Fungsi |
|---|---|---|
| `coderedeem.use` | semua player | `/redeem <kode>` |
| `coderedeem.admin` | op | semua subcommand admin |

## 10. Konfigurasi
`config.yml`: `settings.timezone`, `check-expired-on-redeem`, `auto-disable-expired`, `redeem-cooldown-ms`,
`list-page-size`, `log-redeems`, `storage.type` (yaml).
`messages.yml`: semua teks; warna `&a` dan HEX `&#00AAFF`; pesan yang hilang memakai default bawaan.
`codes.yml`: data kode. Contoh:
```yaml
codes:
  WELCOME2026:
    enabled: true
    description: "Welcome Code"
    expired: "2026-12-31 23:59:59"   # wajib pakai tanda kutip, atau "none"
    max-uses: 100                    # -1 = unlimited
    uses: 0
    one-use-per-player: true
    rewards:
      commands: ["experience add %player% 500 points"]
      display: ["500 XP"]
      items:
        - material: DIAMOND
          amount: 10
          name: "&bDiamond Spesial"
          lore: ["&7Hadiah welcome"]
          enchantments: { unbreaking: 3 }
          custom-model-data: 1
    broadcast: { enabled: false, message: "%player% berhasil menggunakan redeem code!" }
    redeemed-players: []
```
`/redeem set <kode> <field> <nilai>`: field `expired`, `max-uses`, `one-use`, `description`, `broadcast`, `broadcast-message`.

## 11. Contoh penggunaan
```
/redeem create WELCOME2026 100 2026-12-31 23:59:59
/redeem reward WELCOME2026 addcmd give %player% diamond 10
/redeem reward WELCOME2026 adddisplay 10x Diamond
/redeem set WELCOME2026 broadcast true
/redeem info WELCOME2026
```
Player: `/redeem WELCOME2026`

## 12. Troubleshooting
- **Kode berstatus INVALID**: nilai `expired`/`max-uses` di `codes.yml` salah format; perbaiki lewat `/redeem set` atau edit file lalu `/redeem reload`.
- **"Kode belum dapat digunakan"**: kode belum punya hadiah.
- **Reward command gagal**: cek console; command harus valid dan plugin terkait (mis. economy) terpasang.
- **Item jatuh ke tanah**: inventory player penuh.
- **Plugin tidak load**: pastikan Paper 1.21.8 (kompatibel 1.21.x) dan Java 21.
- **Build gagal**: pastikan Java 21 + Maven dan akses ke `repo.papermc.io`.
