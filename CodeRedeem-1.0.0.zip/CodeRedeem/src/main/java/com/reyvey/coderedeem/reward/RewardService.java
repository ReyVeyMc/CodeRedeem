package com.reyvey.coderedeem.reward;

import com.reyvey.coderedeem.CodeRedeem;
import com.reyvey.coderedeem.manager.MessageManager;
import com.reyvey.coderedeem.model.RedeemCode;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

/** Executes rewards of a code for a player. Must be called on the main thread. */
public final class RewardService {

    private final CodeRedeem plugin;
    private final MessageManager messages;

    public RewardService(CodeRedeem plugin, MessageManager messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    /** @return number of rewards that failed */
    public int give(Player player, RedeemCode code) {
        int failures = 0;
        String displayName = PlainTextComponentSerializer.plainText().serialize(player.displayName());

        for (String raw : code.getCommands()) {
            String cmd = raw
                    .replace("%player%", player.getName())
                    .replace("%uuid%", player.getUniqueId().toString())
                    .replace("%displayname%", displayName)
                    .trim();
            if (cmd.startsWith("/")) {
                cmd = cmd.substring(1);
            }
            if (cmd.isEmpty()) {
                continue;
            }
            try {
                if (!Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd)) {
                    failures++;
                    plugin.getLogger().warning("Reward command failed (code " + code.getId() + "): " + cmd);
                }
            } catch (Exception ex) {
                failures++;
                plugin.getLogger().warning("Reward command error (code " + code.getId() + "): " + cmd + " -> " + ex);
            }
        }

        boolean dropped = false;
        for (RewardItem item : code.getItems()) {
            try {
                for (ItemStack stack : item.build()) {
                    Map<Integer, ItemStack> left = player.getInventory().addItem(stack);
                    for (ItemStack l : left.values()) {
                        dropped = true;
                        player.getWorld().dropItemNaturally(player.getLocation(), l);
                    }
                }
            } catch (Exception ex) {
                failures++;
                plugin.getLogger().warning("Reward item error (code " + code.getId() + "): " + ex.getMessage());
            }
        }
        if (dropped) {
            messages.send(player, "inventory-full");
        }
        return failures;
    }
}
