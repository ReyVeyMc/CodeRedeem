package com.reyvey.coderedeem.reward;

import com.reyvey.coderedeem.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Configurable item reward (material, amount, name, lore, enchantments, custom model data). */
public final class RewardItem {

    private String material = "STONE";
    private int amount = 1;
    private String name;
    private final List<String> lore = new ArrayList<>();
    private final Map<String, Integer> enchantments = new LinkedHashMap<>();
    private Integer customModelData;

    public static RewardItem fromMap(Map<?, ?> map) {
        RewardItem r = new RewardItem();
        Object mat = map.get("material");
        if (mat == null) {
            throw new IllegalArgumentException("material is missing");
        }
        r.material = String.valueOf(mat).trim().toUpperCase(Locale.ROOT);
        Object a = map.get("amount");
        if (a instanceof Number n) {
            r.amount = n.intValue();
        } else if (a != null) {
            r.amount = Integer.parseInt(String.valueOf(a).trim());
        }
        if (r.amount < 1) {
            r.amount = 1;
        }
        Object n = map.get("name") != null ? map.get("name") : map.get("display-name");
        if (n != null) {
            r.name = String.valueOf(n);
        }
        if (map.get("lore") instanceof List<?> list) {
            for (Object o : list) {
                r.lore.add(String.valueOf(o));
            }
        }
        if (map.get("enchantments") instanceof Map<?, ?> em) {
            for (Map.Entry<?, ?> e : em.entrySet()) {
                int level = e.getValue() instanceof Number num ? num.intValue()
                        : Integer.parseInt(String.valueOf(e.getValue()).trim());
                r.enchantments.put(String.valueOf(e.getKey()).toLowerCase(Locale.ROOT), level);
            }
        }
        if (map.get("custom-model-data") instanceof Number c) {
            r.customModelData = c.intValue();
        }
        return r;
    }

    public static RewardItem fromItemStack(ItemStack item) {
        RewardItem r = new RewardItem();
        r.material = item.getType().name();
        r.amount = Math.max(1, item.getAmount());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (meta.hasDisplayName() && meta.displayName() != null) {
                r.name = ColorUtil.serialize(meta.displayName());
            }
            if (meta.hasLore() && meta.lore() != null) {
                for (Component c : meta.lore()) {
                    r.lore.add(ColorUtil.serialize(c));
                }
            }
            for (Map.Entry<Enchantment, Integer> e : meta.getEnchants().entrySet()) {
                r.enchantments.put(e.getKey().getKey().getKey(), e.getValue());
            }
            if (meta instanceof EnchantmentStorageMeta esm) {
                for (Map.Entry<Enchantment, Integer> e : esm.getStoredEnchants().entrySet()) {
                    r.enchantments.put(e.getKey().getKey().getKey(), e.getValue());
                }
            }
            if (meta.hasCustomModelDataComponent()) {
                List<Float> floats = meta.getCustomModelDataComponent().getFloats();
                if (!floats.isEmpty()) {
                    r.customModelData = Math.round(floats.get(0));
                }
            }
        }
        return r;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("material", material);
        m.put("amount", amount);
        if (name != null && !name.isBlank()) {
            m.put("name", name);
        }
        if (!lore.isEmpty()) {
            m.put("lore", new ArrayList<>(lore));
        }
        if (!enchantments.isEmpty()) {
            m.put("enchantments", new LinkedHashMap<>(enchantments));
        }
        if (customModelData != null) {
            m.put("custom-model-data", customModelData);
        }
        return m;
    }

    /** Builds the item stacks (split by max stack size). Throws IllegalStateException on invalid config. */
    public List<ItemStack> build() {
        Material mat = Material.matchMaterial(material);
        if (mat == null || mat.isAir() || !mat.isItem()) {
            throw new IllegalStateException("Invalid material: " + material);
        }
        ItemStack template = new ItemStack(mat, 1);
        ItemMeta meta = template.getItemMeta();
        if (meta != null) {
            if (name != null && !name.isBlank()) {
                meta.displayName(ColorUtil.color(name).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE));
            }
            if (!lore.isEmpty()) {
                List<Component> lines = new ArrayList<>();
                for (String l : lore) {
                    lines.add(ColorUtil.color(l).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE));
                }
                meta.lore(lines);
            }
            for (Map.Entry<String, Integer> e : enchantments.entrySet()) {
                Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(e.getKey()));
                if (ench == null) {
                    throw new IllegalStateException("Unknown enchantment: " + e.getKey());
                }
                if (meta instanceof EnchantmentStorageMeta esm) {
                    esm.addStoredEnchant(ench, e.getValue(), true);
                } else {
                    meta.addEnchant(ench, e.getValue(), true);
                }
            }
            if (customModelData != null) {
                CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
                cmd.setFloats(List.of(customModelData.floatValue()));
                meta.setCustomModelDataComponent(cmd);
            }
            template.setItemMeta(meta);
        }
        List<ItemStack> result = new ArrayList<>();
        int remaining = amount;
        int max = Math.max(1, mat.getMaxStackSize());
        while (remaining > 0) {
            int n = Math.min(max, remaining);
            ItemStack stack = template.clone();
            stack.setAmount(n);
            result.add(stack);
            remaining -= n;
        }
        return result;
    }

    /** Text shown to players, e.g. "10x Diamond". */
    public String displayLabel() {
        String label;
        if (name != null && !name.isBlank()) {
            label = ColorUtil.strip(name);
        } else {
            StringBuilder sb = new StringBuilder();
            for (String part : material.toLowerCase(Locale.ROOT).split("_")) {
                if (part.isEmpty()) {
                    continue;
                }
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
            }
            label = sb.toString();
        }
        return amount + "x " + label;
    }
}
