package com.reyvey.coderedeem.model;

import com.reyvey.coderedeem.reward.RewardItem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class RedeemCode {

    private final String id;
    private boolean enabled = true;
    private boolean autoDisabled;
    private String description = "";
    private LocalDateTime expired;
    private String expiredRaw;      // non-null = value in file was invalid (kept as-is)
    private int maxUses = -1;
    private Object maxUsesRaw;      // non-null = value in file was invalid (kept as-is)
    private int uses;
    private boolean oneUsePerPlayer = true;
    private final List<String> commands = new ArrayList<>();
    private final List<String> display = new ArrayList<>();
    private final List<RewardItem> items = new ArrayList<>();
    private boolean broadcastEnabled;
    private String broadcastMessage = "%player% berhasil menggunakan redeem code!";
    private final Set<UUID> redeemedPlayers = new LinkedHashSet<>();

    public RedeemCode(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isAutoDisabled() {
        return autoDisabled;
    }

    public void setAutoDisabled(boolean autoDisabled) {
        this.autoDisabled = autoDisabled;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? "" : description;
    }

    public LocalDateTime getExpired() {
        return expired;
    }

    public void setExpired(LocalDateTime expired) {
        this.expired = expired;
        this.expiredRaw = null;
    }

    public String getExpiredRaw() {
        return expiredRaw;
    }

    public void setExpiredRaw(String expiredRaw) {
        this.expiredRaw = expiredRaw;
    }

    public int getMaxUses() {
        return maxUses;
    }

    public void setMaxUses(int maxUses) {
        this.maxUses = maxUses;
        this.maxUsesRaw = null;
    }

    public Object getMaxUsesRaw() {
        return maxUsesRaw;
    }

    public void setMaxUsesRaw(Object maxUsesRaw) {
        this.maxUsesRaw = maxUsesRaw;
    }

    public int getUses() {
        return uses;
    }

    public void setUses(int uses) {
        this.uses = Math.max(0, uses);
    }

    public boolean isOneUsePerPlayer() {
        return oneUsePerPlayer;
    }

    public void setOneUsePerPlayer(boolean oneUsePerPlayer) {
        this.oneUsePerPlayer = oneUsePerPlayer;
    }

    public List<String> getCommands() {
        return commands;
    }

    public List<String> getDisplay() {
        return display;
    }

    public List<RewardItem> getItems() {
        return items;
    }

    public boolean isBroadcastEnabled() {
        return broadcastEnabled;
    }

    public void setBroadcastEnabled(boolean broadcastEnabled) {
        this.broadcastEnabled = broadcastEnabled;
    }

    public String getBroadcastMessage() {
        return broadcastMessage;
    }

    public void setBroadcastMessage(String broadcastMessage) {
        this.broadcastMessage = broadcastMessage == null ? "" : broadcastMessage;
    }

    public Set<UUID> getRedeemedPlayers() {
        return redeemedPlayers;
    }

    public boolean hasRedeemed(UUID uuid) {
        return redeemedPlayers.contains(uuid);
    }

    /** True when the stored configuration of this code is invalid and it must not be redeemed. */
    public boolean isInvalid() {
        return expiredRaw != null || maxUsesRaw != null;
    }

    public boolean isFull() {
        return maxUses >= 0 && uses >= maxUses;
    }

    public boolean hasNoRewards() {
        return commands.isEmpty() && items.isEmpty();
    }

    public void recordUse(UUID uuid) {
        uses++;
        redeemedPlayers.add(uuid);
    }
}
