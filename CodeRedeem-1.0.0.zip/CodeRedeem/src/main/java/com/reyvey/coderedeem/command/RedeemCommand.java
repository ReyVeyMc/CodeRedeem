package com.reyvey.coderedeem.command;

import com.reyvey.coderedeem.CodeRedeem;
import com.reyvey.coderedeem.manager.CodeManager;
import com.reyvey.coderedeem.manager.MessageManager;
import com.reyvey.coderedeem.model.RedeemCode;
import com.reyvey.coderedeem.reward.RewardItem;
import com.reyvey.coderedeem.util.ColorUtil;
import com.reyvey.coderedeem.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/** Handles /redeem and all of its subcommands. */
public final class RedeemCommand implements TabExecutor {

    private static final String PERM_ADMIN = "coderedeem.admin";
    private static final String PERM_USE = "coderedeem.use";
    private static final List<String> SUBS =
            List.of("help", "list", "info", "create", "delete", "enable", "disable", "set", "reward", "reload");
    private static final Set<String> RESERVED = Set.copyOf(SUBS);
    private static final List<String> SET_FIELDS =
            List.of("expired", "max-uses", "one-use", "description", "broadcast", "broadcast-message");
    private static final List<String> REWARD_ACTIONS =
            List.of("addcmd", "delcmd", "additem", "delitem", "adddisplay", "deldisplay");
    private static final Pattern NAME = Pattern.compile("^[A-Za-z0-9_-]{3,32}$");
    private static final Pattern DATE_ONLY = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

    private final CodeRedeem plugin;
    private final MessageManager messages;
    private final CodeManager codes;

    public RedeemCommand(CodeRedeem plugin, MessageManager messages, CodeManager codes) {
        this.plugin = plugin;
        this.messages = messages;
        this.codes = codes;
    }

    private boolean isAdmin(CommandSender s) {
        return s.hasPermission(PERM_ADMIN);
    }

    // ------------------------------------------------------------------ execute

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            if (args.length == 0) {
                if (isAdmin(sender)) {
                    sendHelp(sender);
                } else {
                    messages.send(sender, "usage-redeem");
                }
                return true;
            }
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (!RESERVED.contains(sub)) {
                handleRedeem(sender, args);
                return true;
            }
            if (sub.equals("help")) {
                sendHelp(sender);
                return true;
            }
            if (!isAdmin(sender)) {
                messages.send(sender, "no-permission");
                return true;
            }
            switch (sub) {
                case "list" -> list(sender, args);
                case "info" -> info(sender, args);
                case "create" -> create(sender, args);
                case "delete" -> delete(sender, args);
                case "enable" -> toggle(sender, args, true);
                case "disable" -> toggle(sender, args, false);
                case "set" -> set(sender, args);
                case "reward" -> reward(sender, args);
                case "reload" -> reload(sender);
                default -> sendHelp(sender);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Error while executing /redeem: " + e);
            messages.send(sender, "usage", "usage", "/redeem help");
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        messages.sendLines(sender, isAdmin(sender) ? "help-admin" : "help-player", null, null);
    }

    // ------------------------------------------------------------------ player redeem

    private void handleRedeem(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            messages.send(sender, "player-only");
            return;
        }
        if (!player.hasPermission(PERM_USE)) {
            messages.send(player, "no-permission");
            return;
        }
        if (args.length != 1) {
            messages.send(player, "usage-redeem");
            return;
        }
        CodeManager.Outcome o = codes.redeem(player, args[0]);
        switch (o.result()) {
            case SUCCESS -> {
                RedeemCode code = o.code();
                Map<String, List<String>> lph = new HashMap<>();
                lph.put("rewards", rewardLines(code));
                messages.sendLines(player, "redeem-success",
                        MessageManager.map("code", code.getId(), "player", player.getName()), lph);
                if (o.rewardFailures() > 0) {
                    messages.send(player, "reward-failed", "code", code.getId());
                    plugin.getLogger().warning(o.rewardFailures() + " reward(s) failed for " + player.getName()
                            + " using code " + code.getId());
                }
                if (code.isBroadcastEnabled() && !code.getBroadcastMessage().isBlank()) {
                    String msg = code.getBroadcastMessage()
                            .replace("%player%", player.getName())
                            .replace("%code%", code.getId());
                    Bukkit.broadcast(ColorUtil.color(msg));
                }
                if (plugin.getConfig().getBoolean("settings.log-redeems", true)) {
                    plugin.getLogger().info(player.getName() + " (" + player.getUniqueId() + ") redeemed " + code.getId());
                }
            }
            case NOT_FOUND -> messages.send(player, "redeem-not-found");
            case EXPIRED -> messages.send(player, "redeem-expired");
            case DISABLED -> messages.send(player, "redeem-disabled");
            case FULL -> messages.send(player, "redeem-full");
            case ALREADY_USED -> messages.send(player, "redeem-already-used");
            case CONFIG_ERROR -> messages.send(player, "redeem-config-error");
            case COOLDOWN -> messages.send(player, "redeem-cooldown");
        }
    }

    /** Player-facing reward lines (never shows console commands). */
    private List<String> rewardLines(RedeemCode code) {
        List<String> out = new ArrayList<>();
        for (String d : code.getDisplay()) {
            out.add(messages.text("reward-line", "reward", d));
        }
        for (RewardItem item : code.getItems()) {
            out.add(messages.text("reward-line", "reward", item.displayLabel()));
        }
        if (out.isEmpty()) {
            out.add(messages.text("reward-line", "reward", "-"));
        }
        return out;
    }

    // ------------------------------------------------------------------ admin helpers

    private void usage(CommandSender s, String usage) {
        messages.send(s, "usage", "usage", usage);
    }

    private RedeemCode find(CommandSender s, String id) {
        RedeemCode c = codes.get(id);
        if (c == null) {
            messages.send(s, "code-not-found", "code", id);
        }
        return c;
    }

    private String statusText(RedeemCode c) {
        return messages.text("status-" + codes.statusOf(c).name().toLowerCase(Locale.ROOT));
    }

    private String maxText(RedeemCode c) {
        if (c.getMaxUsesRaw() != null) {
            return String.valueOf(c.getMaxUsesRaw());
        }
        return c.getMaxUses() < 0 ? messages.text("unlimited") : String.valueOf(c.getMaxUses());
    }

    private String expiredText(RedeemCode c, boolean full) {
        if (c.getExpiredRaw() != null) {
            return c.getExpiredRaw();
        }
        if (c.getExpired() == null) {
            return messages.text("never");
        }
        return TimeUtil.format(c.getExpired(), messages.text(full ? "format-date-full" : "format-date-short"));
    }

    private List<String> indexed(List<String> values) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            out.add("&7" + (i + 1) + ". &f" + values.get(i));
        }
        if (out.isEmpty()) {
            out.add("&7-");
        }
        return out;
    }

    /** Parses a 1-based index; returns -1 and sends a message when invalid. */
    private int index(CommandSender s, String raw, int size) {
        try {
            int i = Integer.parseInt(raw.trim());
            if (i >= 1 && i <= size) {
                return i - 1;
            }
            messages.send(s, "reward-bad-index");
        } catch (NumberFormatException e) {
            messages.send(s, "invalid-number");
        }
        return -1;
    }

    // ------------------------------------------------------------------ admin: list / info

    private void list(CommandSender s, String[] args) {
        List<RedeemCode> all = new ArrayList<>(codes.all());
        if (all.isEmpty()) {
            messages.send(s, "list-empty");
            return;
        }
        int size = Math.max(1, plugin.getConfig().getInt("settings.list-page-size", 5));
        int pages = (all.size() + size - 1) / size;
        int page = 1;
        if (args.length >= 2) {
            try {
                page = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                page = -1;
            }
            if (page < 1 || page > pages) {
                messages.send(s, "list-invalid-page", "pages", String.valueOf(pages));
                return;
            }
        }
        Map<String, String> pagePh = MessageManager.map("page", String.valueOf(page), "pages", String.valueOf(pages));
        messages.sendLines(s, "list-header", pagePh, null);
        int from = (page - 1) * size;
        int to = Math.min(all.size(), from + size);
        for (int i = from; i < to; i++) {
            RedeemCode c = all.get(i);
            messages.sendLines(s, "list-entry", MessageManager.map(
                    "code", c.getId(),
                    "status", statusText(c),
                    "uses", String.valueOf(c.getUses()),
                    "max", maxText(c),
                    "expired", expiredText(c, false)), null);
        }
        messages.sendLines(s, "list-footer", pagePh, null);
    }

    private void info(CommandSender s, String[] args) {
        if (args.length < 2) {
            usage(s, "/redeem info <kode>");
            return;
        }
        RedeemCode c = find(s, args[1]);
        if (c == null) {
            return;
        }
        Map<String, String> ph = MessageManager.map(
                "code", c.getId(),
                "status", statusText(c),
                "description", c.getDescription().isBlank() ? "-" : c.getDescription(),
                "uses", String.valueOf(c.getUses()),
                "max", maxText(c),
                "expired", expiredText(c, true),
                "one_use", String.valueOf(c.isOneUsePerPlayer()).toUpperCase(Locale.ROOT),
                "broadcast", String.valueOf(c.isBroadcastEnabled()).toUpperCase(Locale.ROOT));
        List<String> itemLabels = new ArrayList<>();
        for (RewardItem item : c.getItems()) {
            itemLabels.add(item.displayLabel());
        }
        Map<String, List<String>> lph = new HashMap<>();
        lph.put("rewards", rewardLines(c));
        lph.put("commands", indexed(c.getCommands()));
        lph.put("items", indexed(itemLabels));
        lph.put("display", indexed(c.getDisplay()));
        messages.sendLines(s, "info", ph, lph);
    }

    // ------------------------------------------------------------------ admin: create / delete / toggle

    private void create(CommandSender s, String[] args) {
        if (args.length < 2) {
            usage(s, "/redeem create <kode> [max-use] [expired]");
            return;
        }
        String raw = args[1];
        if (!NAME.matcher(raw).matches()) {
            messages.send(s, "create-invalid-name");
            return;
        }
        String id = raw.toUpperCase(Locale.ROOT);
        if (RESERVED.contains(id.toLowerCase(Locale.ROOT))) {
            messages.send(s, "create-reserved-name", "code", id);
            return;
        }
        if (codes.get(id) != null) {
            messages.send(s, "create-exists", "code", id);
            return;
        }
        int max = -1;
        if (args.length >= 3) {
            try {
                max = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                messages.send(s, "invalid-max-uses");
                return;
            }
            if (max != -1 && max < 1) {
                messages.send(s, "invalid-max-uses");
                return;
            }
        }
        LocalDateTime expired = null;
        if (args.length >= 4) {
            String dateRaw = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
            if (!TimeUtil.isNone(dateRaw)) {
                try {
                    expired = TimeUtil.parse(dateRaw);
                } catch (IllegalArgumentException e) {
                    messages.send(s, "invalid-date");
                    return;
                }
            }
        }
        RedeemCode code = new RedeemCode(id);
        code.setMaxUses(max);
        code.setExpired(expired);
        codes.add(code);
        messages.send(s, "create-success", "code", id);
    }

    private void delete(CommandSender s, String[] args) {
        if (args.length < 2) {
            usage(s, "/redeem delete <kode> [confirm]");
            return;
        }
        RedeemCode c = find(s, args[1]);
        if (c == null) {
            return;
        }
        if (args.length < 3 || !args[2].equalsIgnoreCase("confirm")) {
            messages.send(s, "delete-confirm", "code", c.getId());
            return;
        }
        codes.remove(c.getId());
        messages.send(s, "delete-success", "code", c.getId());
    }

    private void toggle(CommandSender s, String[] args, boolean enable) {
        if (args.length < 2) {
            usage(s, "/redeem " + (enable ? "enable" : "disable") + " <kode>");
            return;
        }
        RedeemCode c = find(s, args[1]);
        if (c == null) {
            return;
        }
        c.setEnabled(enable);
        c.setAutoDisabled(false);
        codes.save();
        messages.send(s, enable ? "enable-success" : "disable-success", "code", c.getId());
    }

    private void reload(CommandSender s) {
        if (plugin.reloadAll()) {
            messages.send(s, "reload-success");
        } else {
            messages.send(s, "reload-failed");
        }
    }

    // ------------------------------------------------------------------ admin: set

    private void set(CommandSender s, String[] args) {
        if (args.length < 4) {
            usage(s, "/redeem set <kode> <field> <nilai>");
            return;
        }
        RedeemCode c = find(s, args[1]);
        if (c == null) {
            return;
        }
        String field = args[2].toLowerCase(Locale.ROOT);
        String value = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
        switch (field) {
            case "expired" -> {
                if (TimeUtil.isNone(value)) {
                    c.setExpired(null);
                } else {
                    try {
                        c.setExpired(TimeUtil.parse(value));
                    } catch (IllegalArgumentException e) {
                        messages.send(s, "invalid-date");
                        return;
                    }
                }
                codes.afterExpiryChange(c);
            }
            case "max-uses", "maxuses" -> {
                try {
                    int max = Integer.parseInt(value.trim());
                    if (max != -1 && max < 1) {
                        messages.send(s, "invalid-max-uses");
                        return;
                    }
                    c.setMaxUses(max);
                } catch (NumberFormatException e) {
                    messages.send(s, "invalid-max-uses");
                    return;
                }
            }
            case "one-use", "one-use-per-player" -> {
                Boolean b = parseBool(value);
                if (b == null) {
                    messages.send(s, "invalid-boolean");
                    return;
                }
                c.setOneUsePerPlayer(b);
            }
            case "description" -> c.setDescription(value);
            case "broadcast" -> {
                Boolean b = parseBool(value);
                if (b == null) {
                    messages.send(s, "invalid-boolean");
                    return;
                }
                c.setBroadcastEnabled(b);
            }
            case "broadcast-message" -> c.setBroadcastMessage(value);
            default -> {
                messages.send(s, "set-unknown-field", "fields", String.join(", ", SET_FIELDS));
                return;
            }
        }
        codes.save();
        messages.send(s, "set-success", "field", field, "code", c.getId(), "value", value);
    }

    private static Boolean parseBool(String v) {
        String t = v.trim().toLowerCase(Locale.ROOT);
        if (t.equals("true") || t.equals("yes") || t.equals("on")) {
            return Boolean.TRUE;
        }
        if (t.equals("false") || t.equals("no") || t.equals("off")) {
            return Boolean.FALSE;
        }
        return null;
    }

    // ------------------------------------------------------------------ admin: reward

    private void reward(CommandSender s, String[] args) {
        String usage = "/redeem reward <kode> <" + String.join("|", REWARD_ACTIONS) + "> [nilai]";
        if (args.length < 3) {
            usage(s, usage);
            return;
        }
        RedeemCode c = find(s, args[1]);
        if (c == null) {
            return;
        }
        String action = args[2].toLowerCase(Locale.ROOT);
        String rest = args.length > 3 ? String.join(" ", Arrays.copyOfRange(args, 3, args.length)) : "";
        switch (action) {
            case "addcmd" -> {
                String cmd = rest.trim();
                if (cmd.startsWith("/")) {
                    cmd = cmd.substring(1);
                }
                if (cmd.isEmpty()) {
                    usage(s, "/redeem reward " + c.getId() + " addcmd <command>");
                    return;
                }
                c.getCommands().add(cmd);
                messages.send(s, "reward-command-added", "code", c.getId());
            }
            case "delcmd" -> {
                int i = index(s, rest, c.getCommands().size());
                if (i < 0) {
                    return;
                }
                c.getCommands().remove(i);
                messages.send(s, "reward-command-removed", "code", c.getId(), "index", String.valueOf(i + 1));
            }
            case "additem" -> {
                if (!(s instanceof Player p)) {
                    messages.send(s, "player-only");
                    return;
                }
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType() == Material.AIR || hand.getAmount() < 1) {
                    messages.send(s, "reward-hold-item");
                    return;
                }
                RewardItem item = RewardItem.fromItemStack(hand);
                c.getItems().add(item);
                messages.send(s, "reward-item-added", "code", c.getId(), "item", item.displayLabel());
            }
            case "delitem" -> {
                int i = index(s, rest, c.getItems().size());
                if (i < 0) {
                    return;
                }
                c.getItems().remove(i);
                messages.send(s, "reward-item-removed", "code", c.getId(), "index", String.valueOf(i + 1));
            }
            case "adddisplay" -> {
                if (rest.isBlank()) {
                    usage(s, "/redeem reward " + c.getId() + " adddisplay <teks>");
                    return;
                }
                c.getDisplay().add(rest);
                messages.send(s, "reward-display-added", "code", c.getId());
            }
            case "deldisplay" -> {
                int i = index(s, rest, c.getDisplay().size());
                if (i < 0) {
                    return;
                }
                c.getDisplay().remove(i);
                messages.send(s, "reward-display-removed", "code", c.getId(), "index", String.valueOf(i + 1));
            }
            default -> {
                usage(s, usage);
                return;
            }
        }
        codes.save();
    }

    // ------------------------------------------------------------------ tab completion

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!isAdmin(sender)) {
            return List.of();
        }
        String cur = args[args.length - 1];
        if (args.length == 1) {
            return filter(SUBS, cur);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        String sample = codes.now().plusDays(30).toLocalDate().toString();

        if (sub.equals("info") || sub.equals("enable") || sub.equals("disable")) {
            return args.length == 2 ? filter(codes.ids(), cur) : List.of();
        }
        if (sub.equals("delete")) {
            if (args.length == 2) {
                return filter(codes.ids(), cur);
            }
            return args.length == 3 ? filter(List.of("confirm"), cur) : List.of();
        }
        if (sub.equals("list")) {
            if (args.length == 2) {
                int size = Math.max(1, plugin.getConfig().getInt("settings.list-page-size", 5));
                int pages = Math.max(1, (codes.all().size() + size - 1) / size);
                List<String> nums = new ArrayList<>();
                for (int i = 1; i <= pages && i <= 20; i++) {
                    nums.add(String.valueOf(i));
                }
                return filter(nums, cur);
            }
            return List.of();
        }
        if (sub.equals("create")) {
            if (args.length == 3) {
                return filter(List.of("-1", "10", "50", "100"), cur);
            }
            if (args.length == 4) {
                return filter(List.of("none", sample), cur);
            }
            if (args.length == 5 && DATE_ONLY.matcher(args[3]).matches()) {
                return filter(List.of("23:59:59"), cur);
            }
            return List.of();
        }
        if (sub.equals("set")) {
            if (args.length == 2) {
                return filter(codes.ids(), cur);
            }
            if (args.length == 3) {
                return filter(SET_FIELDS, cur);
            }
            if (args.length == 4) {
                String f = args[2].toLowerCase(Locale.ROOT);
                if (f.equals("one-use") || f.equals("broadcast")) {
                    return filter(List.of("true", "false"), cur);
                }
                if (f.equals("expired")) {
                    return filter(List.of("none", sample), cur);
                }
                if (f.equals("max-uses")) {
                    return filter(List.of("-1", "10", "50", "100"), cur);
                }
            }
            if (args.length == 5 && args[2].equalsIgnoreCase("expired") && DATE_ONLY.matcher(args[3]).matches()) {
                return filter(List.of("23:59:59"), cur);
            }
            return List.of();
        }
        if (sub.equals("reward")) {
            if (args.length == 2) {
                return filter(codes.ids(), cur);
            }
            if (args.length == 3) {
                return filter(REWARD_ACTIONS, cur);
            }
            if (args.length == 4) {
                RedeemCode c = codes.get(args[1]);
                if (c != null) {
                    String a = args[2].toLowerCase(Locale.ROOT);
                    int size = a.equals("delcmd") ? c.getCommands().size()
                            : a.equals("delitem") ? c.getItems().size()
                            : a.equals("deldisplay") ? c.getDisplay().size() : 0;
                    List<String> nums = new ArrayList<>();
                    for (int i = 1; i <= size; i++) {
                        nums.add(String.valueOf(i));
                    }
                    return filter(nums, cur);
                }
            }
            return List.of();
        }
        return List.of();
    }

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                out.add(o);
            }
        }
        return out;
    }
}
