package com.reyvey.coderedeem.storage;

import com.reyvey.coderedeem.CodeRedeem;
import com.reyvey.coderedeem.model.RedeemCode;
import com.reyvey.coderedeem.reward.RewardItem;
import com.reyvey.coderedeem.util.TimeUtil;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/** YAML storage (codes.yml). Writes are atomic and performed on a single IO thread. */
public final class CodeStorage {

    private final CodeRedeem plugin;
    private final File file;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "CodeRedeem-IO");
        t.setDaemon(true);
        return t;
    });

    public CodeStorage(CodeRedeem plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "codes.yml");
    }

    /** @return loaded codes, or null if the file is corrupt (a backup copy is made). */
    public Map<String, RedeemCode> load() {
        Map<String, RedeemCode> result = new TreeMap<>();
        if (!file.exists()) {
            return result;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(file);
        } catch (IOException | InvalidConfigurationException e) {
            plugin.getLogger().log(Level.SEVERE, "codes.yml is corrupt and could not be loaded!", e);
            backupBroken();
            return null;
        }
        ConfigurationSection root = yaml.getConfigurationSection("codes");
        if (root == null) {
            return result;
        }
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) {
                plugin.getLogger().warning("Skipping code '" + key + "': not a valid section.");
                continue;
            }
            try {
                RedeemCode code = parse(key, s);
                if (result.containsKey(code.getId())) {
                    plugin.getLogger().warning("Duplicate code '" + key + "' (case-insensitive); the last one is used.");
                }
                result.put(code.getId(), code);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Skipping code '" + key + "': " + e.getMessage(), e);
            }
        }
        return result;
    }

    private RedeemCode parse(String key, ConfigurationSection s) {
        RedeemCode c = new RedeemCode(key.toUpperCase(Locale.ROOT));
        c.setEnabled(s.getBoolean("enabled", true));
        c.setAutoDisabled(s.getBoolean("auto-disabled", false));
        c.setDescription(s.getString("description", ""));
        c.setOneUsePerPlayer(s.getBoolean("one-use-per-player", true));
        c.setUses(s.getInt("uses", 0));

        // expired
        Object exp = s.get("expired");
        try {
            if (exp instanceof Date d) {
                c.setExpired(LocalDateTime.ofInstant(d.toInstant(), ZoneOffset.UTC));
            } else if (exp == null || TimeUtil.isNone(String.valueOf(exp))) {
                c.setExpired(null);
            } else {
                c.setExpired(TimeUtil.parse(String.valueOf(exp)));
            }
        } catch (IllegalArgumentException e) {
            c.setExpiredRaw(String.valueOf(exp));
            plugin.getLogger().warning("Code " + c.getId() + ": invalid 'expired' value '" + exp
                    + "' (code is disabled until fixed). Use \"YYYY-MM-DD HH:mm:ss\" or \"none\".");
        }

        // max-uses
        Object mu = s.get("max-uses");
        if (mu == null) {
            c.setMaxUses(-1);
        } else {
            try {
                int v = mu instanceof Number n ? n.intValue() : Integer.parseInt(String.valueOf(mu).trim());
                if (v < -1) {
                    throw new NumberFormatException("below -1");
                }
                c.setMaxUses(v);
            } catch (NumberFormatException e) {
                c.setMaxUsesRaw(mu);
                plugin.getLogger().warning("Code " + c.getId() + ": invalid 'max-uses' value '" + mu
                        + "' (code is disabled until fixed).");
            }
        }

        // rewards
        c.getCommands().addAll(s.getStringList("rewards.commands"));
        c.getDisplay().addAll(s.getStringList("rewards.display"));
        for (Map<?, ?> m : s.getMapList("rewards.items")) {
            try {
                c.getItems().add(RewardItem.fromMap(m));
            } catch (Exception e) {
                plugin.getLogger().warning("Code " + c.getId() + ": skipping invalid item reward: " + e.getMessage());
            }
        }

        // broadcast
        c.setBroadcastEnabled(s.getBoolean("broadcast.enabled", false));
        c.setBroadcastMessage(s.getString("broadcast.message", c.getBroadcastMessage()));

        // redeemed players (UUID only)
        for (String u : s.getStringList("redeemed-players")) {
            try {
                c.getRedeemedPlayers().add(UUID.fromString(u.trim()));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Code " + c.getId() + ": ignoring invalid UUID '" + u + "'");
            }
        }
        return c;
    }

    /** Serializes on the caller thread, writes asynchronously and atomically. */
    public void save(Collection<RedeemCode> codes) {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.createSection("codes");
        for (RedeemCode c : codes) {
            String base = "codes." + c.getId();
            yaml.set(base + ".enabled", c.isEnabled());
            if (c.isAutoDisabled()) {
                yaml.set(base + ".auto-disabled", true);
            }
            yaml.set(base + ".description", c.getDescription());
            if (c.getExpiredRaw() != null) {
                yaml.set(base + ".expired", c.getExpiredRaw());
            } else {
                yaml.set(base + ".expired", c.getExpired() == null ? "none" : TimeUtil.STORE.format(c.getExpired()));
            }
            if (c.getMaxUsesRaw() != null) {
                yaml.set(base + ".max-uses", c.getMaxUsesRaw());
            } else {
                yaml.set(base + ".max-uses", c.getMaxUses());
            }
            yaml.set(base + ".uses", c.getUses());
            yaml.set(base + ".one-use-per-player", c.isOneUsePerPlayer());
            yaml.set(base + ".rewards.commands", new ArrayList<>(c.getCommands()));
            yaml.set(base + ".rewards.display", new ArrayList<>(c.getDisplay()));
            List<Map<String, Object>> items = new ArrayList<>();
            for (RewardItem item : c.getItems()) {
                items.add(item.toMap());
            }
            yaml.set(base + ".rewards.items", items);
            yaml.set(base + ".broadcast.enabled", c.isBroadcastEnabled());
            yaml.set(base + ".broadcast.message", c.getBroadcastMessage());
            List<String> players = new ArrayList<>();
            for (UUID u : c.getRedeemedPlayers()) {
                players.add(u.toString());
            }
            yaml.set(base + ".redeemed-players", players);
        }
        String data = yaml.saveToString();
        try {
            io.execute(() -> write(data));
        } catch (RuntimeException e) {
            write(data); // executor already shut down
        }
    }

    private void write(String data) {
        try {
            File dir = file.getParentFile();
            if (dir != null && !dir.exists() && !dir.mkdirs()) {
                throw new IOException("Cannot create " + dir);
            }
            File tmp = new File(dir, "codes.yml.tmp");
            Files.writeString(tmp.toPath(), data, StandardCharsets.UTF_8);
            try {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to save codes.yml!", e);
        }
    }

    private void backupBroken() {
        try {
            String stamp = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").format(LocalDateTime.now());
            File backup = new File(file.getParentFile(), "codes.yml.broken-" + stamp);
            Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            plugin.getLogger().warning("A copy of the broken file was saved as " + backup.getName());
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not back up the broken codes.yml", e);
        }
    }

    /** Waits for pending writes. Call from onDisable. */
    public void close() {
        io.shutdown();
        try {
            if (!io.awaitTermination(10, TimeUnit.SECONDS)) {
                plugin.getLogger().warning("Timed out waiting for codes.yml to be written.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
