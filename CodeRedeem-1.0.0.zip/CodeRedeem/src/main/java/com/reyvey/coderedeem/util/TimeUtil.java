package com.reyvey.coderedeem.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;

public final class TimeUtil {

    public static final DateTimeFormatter STORE =
            DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss").withResolverStyle(ResolverStyle.STRICT);

    private TimeUtil() {
    }

    /** True for values meaning "no expiry". */
    public static boolean isNone(String raw) {
        if (raw == null) {
            return true;
        }
        String s = raw.trim().toLowerCase(Locale.ROOT);
        return s.isEmpty() || s.equals("none") || s.equals("never") || s.equals("permanent")
                || s.equals("null") || s.equals("-");
    }

    /** Parses "YYYY-MM-DD HH:mm:ss", "YYYY-MM-DDTHH:mm:ss" or "YYYY-MM-DD" (= 23:59:59). */
    public static LocalDateTime parse(String raw) {
        if (raw == null) {
            throw new IllegalArgumentException("empty date");
        }
        String s = raw.trim().replace('T', ' ');
        try {
            if (s.length() == 10) {
                return LocalDate.parse(s).atTime(23, 59, 59);
            }
            return LocalDateTime.parse(s, STORE);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("invalid date: " + raw, e);
        }
    }

    public static String format(LocalDateTime time, String pattern) {
        try {
            return DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH).format(time);
        } catch (IllegalArgumentException e) {
            return STORE.format(time);
        }
    }
}
