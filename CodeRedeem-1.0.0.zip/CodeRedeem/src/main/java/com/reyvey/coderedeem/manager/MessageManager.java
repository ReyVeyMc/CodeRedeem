package com.reyvey.coderedeem.manager;

import com.reyvey.coderedeem.CodeRedeem;
import com.reyvey.coderedeem.util.ColorUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/** Loads messages.yml (with fallback to bundled defaults) and sends colored messages. */
public final class MessageManager {

    private final CodeRedeem plugin;
    private YamlConfiguration user = new YamlConfiguration();
    private YamlConfiguration defaults = new YamlConfiguration();

    public MessageManager(CodeRedeem plugin) {
        this.plugin = plugin;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        YamlConfiguration loaded = new YamlConfiguration();
        try {
            loaded.load(file);
        } catch (IOException | InvalidConfigurationException e) {
            plugin.getLogger().log(Level.SEVERE, "messages.yml is invalid, using built-in defaults.", e);
        }
        user = loaded;

        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                YamlConfiguration d = new YamlConfiguration();
                d.load(new InputStreamReader(in, StandardCharsets.UTF_8));
                defaults = d;
            }
        } catch (IOException | InvalidConfigurationException e) {
            plugin.getLogger().log(Level.WARNING, "Could not read bundled messages.yml", e);
        }
    }

    private List<String> raw(String key) {
        Object v = user.get(key);
        if (v == null) {
            v = defaults.get(key);
        }
        if (v instanceof List<?> list) {
            List<String> out = new ArrayList<>();
            for (Object o : list) {
                out.add(String.valueOf(o));
            }
            return out;
        }
        if (v != null && !(v instanceof ConfigurationSection)) {
            return List.of(String.valueOf(v));
        }
        return List.of("&c[CodeRedeem] Missing message: " + key);
    }

    private String first(String key) {
        List<String> l = raw(key);
        return l.isEmpty() ? "" : l.get(0);
    }

    private String replace(String s, Map<String, String> ph) {
        String out = s.replace("%prefix%", first("prefix")).replace("%header%", first("header"));
        if (ph != null) {
            for (Map.Entry<String, String> e : ph.entrySet()) {
                out = out.replace("%" + e.getKey() + "%", e.getValue());
            }
        }
        return out;
    }

    /** Single-line text with placeholders replaced (color codes NOT yet applied). */
    public String text(String key, String... kv) {
        return replace(first(key), map(kv));
    }

    public void send(CommandSender to, String key, String... kv) {
        sendLines(to, key, map(kv), null);
    }

    /**
     * Sends a message. A line consisting only of %name% where name is in listPlaceholders
     * is expanded into multiple lines.
     */
    public void sendLines(CommandSender to, String key, Map<String, String> ph, Map<String, List<String>> listPh) {
        for (String line : raw(key)) {
            String t = line.trim();
            if (listPh != null && t.length() > 2 && t.startsWith("%") && t.endsWith("%")
                    && listPh.containsKey(t.substring(1, t.length() - 1))) {
                for (String x : listPh.get(t.substring(1, t.length() - 1))) {
                    to.sendMessage(ColorUtil.color(replace(x, ph)));
                }
                continue;
            }
            to.sendMessage(ColorUtil.color(replace(line, ph)));
        }
    }

    public static Map<String, String> map(String... kv) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put(kv[i], kv[i + 1]);
        }
        return m;
    }
}
