package com.reyvey.coderedeem;

import com.reyvey.coderedeem.command.RedeemCommand;
import com.reyvey.coderedeem.manager.CodeManager;
import com.reyvey.coderedeem.manager.MessageManager;
import com.reyvey.coderedeem.storage.CodeStorage;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;

/** CodeRedeem by ReyVey - advanced redeem code system. */
public final class CodeRedeem extends JavaPlugin {

    private MessageManager messages;
    private CodeStorage storage;
    private CodeManager codes;
    private BukkitTask expiryTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "codes.yml").exists()) {
            saveResource("codes.yml", false);
        }
        messages = new MessageManager(this);
        messages.load();
        storage = new CodeStorage(this);
        codes = new CodeManager(this, storage, messages);
        codes.reload();

        PluginCommand command = getCommand("redeem");
        if (command == null) {
            getLogger().severe("Command 'redeem' is missing from plugin.yml!");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        RedeemCommand handler = new RedeemCommand(this, messages, codes);
        command.setExecutor(handler);
        command.setTabCompleter(handler);

        expiryTask = getServer().getScheduler().runTaskTimer(this, codes::tickExpiry, 1200L, 1200L);
        getLogger().info("CodeRedeem v" + getPluginMeta().getVersion() + " by ReyVey enabled.");
    }

    @Override
    public void onDisable() {
        if (expiryTask != null) {
            expiryTask.cancel();
        }
        if (codes != null) {
            codes.save();
        }
        if (storage != null) {
            storage.close();
        }
    }

    /** Reloads config.yml, messages.yml and codes.yml. @return false if codes.yml could not be read. */
    public boolean reloadAll() {
        reloadConfig();
        messages.load();
        return codes.reload();
    }
}
