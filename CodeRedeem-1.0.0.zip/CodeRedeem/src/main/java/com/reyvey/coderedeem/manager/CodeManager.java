package com.reyvey.coderedeem.manager;

import com.reyvey.coderedeem.CodeRedeem;
import com.reyvey.coderedeem.model.RedeemCode;
import com.reyvey.coderedeem.reward.RewardService;
import com.reyvey.coderedeem.storage.CodeStorage;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/** Holds all codes in memory and implements the redeem rules. Main-thread only. */
public final class CodeManager {

    public enum Status { ACTIVE, DISABLED, EXPIRED, FULL, INVALID }

    public enum Result { SUCCESS, NOT_FOUND, EXPIRED, DISABLED, FULL, ALREADY_USED, CONFIG_ERROR, COOLDOWN }

    public record Outcome(Result result, RedeemCode code, int rewardFailures) {
    }

    private final CodeRedeem plugin;
    private final CodeStorage storage;
    private final RewardService rewards;
    private final Map<String, RedeemCode> codes = new TreeMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    private ZoneId zone = ZoneId.systemDefault();
    private boolean checkExpiredOnRedeem = true;
    private boolean autoDisableExpired = true;
    private long cooldownMs = 1500;

    public CodeManager(CodeRedeem plugin, CodeStorage storage, MessageManager messages) {
        this.plugin = plugin;
        this.storage = storage;
        this.rewards = new RewardService(plugin, messages);
    }

    private void loadSettings() {
        FileConfiguration cfg = plugin.getConfig();
        String tz = cfg.getString("settings.timezone", "Asia/Jakarta");
        try {
            zone = ZoneId.of(tz);
        } catch (DateTimeException e) {
            plugin.getLogger().warning("Invalid timezone '" + tz + "', using server default.");
            zone = ZoneId.systemDefault();
        }
        checkExpiredOnRedeem = cfg.getBoolean("settings.check-expired-on-redeem", true);
        autoDisableExpired = cfg.getBoolean("settings.auto-disable-expired", true);
        cooldownMs = Math.max(0L, cfg.getLong("settings.redeem-cooldown-ms", 1500L));
    }

    /** Reloads settings and codes.yml. Usage data is preserved because it is stored in codes.yml. */
    public boolean reload() {
        loadSettings();
        Map<String, RedeemCode> loaded = storage.load();
        if (loaded == null) {
            return false;
        }
        codes.clear();
        codes.putAll(loaded);
        return true;
    }

    public void save() {
        storage.save(codes.values());
    }

    public LocalDateTime now() {
        return LocalDateTime.now(zone);
    }

    public Collection<RedeemCode> all() {
        return new ArrayList<>(codes.values());
    }

    public List<String> ids() {
        return new ArrayList<>(codes.keySet());
    }

    public RedeemCode get(String input) {
        if (input == null || input.length() > 64) {
            return null;
        }
        return codes.get(input.toUpperCase(Locale.ROOT));
    }

    public void add(RedeemCode code) {
        codes.put(code.getId(), code);
        save();
    }

    public boolean remove(String id) {
        boolean removed = codes.remove(id.toUpperCase(Locale.ROOT)) != null;
        if (removed) {
            save();
        }
        return removed;
    }

    private boolean isExpiredLive(RedeemCode c) {
        return c.getExpired() != null && now().isAfter(c.getExpired());
    }

    /** Display status (computed live). */
    public Status statusOf(RedeemCode c) {
        if (c.isInvalid()) {
            return Status.INVALID;
        }
        if (c.isAutoDisabled()) {
            return Status.EXPIRED;
        }
        if (!c.isEnabled()) {
            return Status.DISABLED;
        }
        if (isExpiredLive(c)) {
            return Status.EXPIRED;
        }
        if (c.isFull()) {
            return Status.FULL;
        }
        return Status.ACTIVE;
    }

    /** Re-enables a code that was auto-disabled when its expiry has been moved/removed. */
    public void afterExpiryChange(RedeemCode c) {
        if (c.isAutoDisabled() && !isExpiredLive(c)) {
            c.setAutoDisabled(false);
            c.setEnabled(true);
        }
    }

    public Outcome redeem(Player player, String input) {
        UUID uuid = player.getUniqueId();
        long nowMs = System.currentTimeMillis();
        Long last = cooldowns.get(uuid);
        if (last != null && nowMs - last < cooldownMs) {
            return new Outcome(Result.COOLDOWN, null, 0);
        }
        cooldowns.put(uuid, nowMs);

        RedeemCode c = get(input);
        if (c == null) {
            return new Outcome(Result.NOT_FOUND, null, 0);
        }
        if (c.isInvalid() || c.hasNoRewards()) {
            return new Outcome(Result.CONFIG_ERROR, c, 0);
        }
        if (c.isAutoDisabled()) {
            return new Outcome(Result.EXPIRED, c, 0);
        }
        if (!c.isEnabled()) {
            return new Outcome(Result.DISABLED, c, 0);
        }
        if (checkExpiredOnRedeem && isExpiredLive(c)) {
            if (autoDisableExpired) {
                c.setEnabled(false);
                c.setAutoDisabled(true);
                save();
            }
            return new Outcome(Result.EXPIRED, c, 0);
        }
        if (c.isFull()) {
            return new Outcome(Result.FULL, c, 0);
        }
        if (c.isOneUsePerPlayer() && c.hasRedeemed(uuid)) {
            return new Outcome(Result.ALREADY_USED, c, 0);
        }

        // Record the use BEFORE giving rewards: prevents double-redeem and duplicate rewards.
        c.recordUse(uuid);
        save();
        int failures = rewards.give(player, c);
        return new Outcome(Result.SUCCESS, c, failures);
    }

    /** Periodic task: auto-disable expired codes and clean cooldown map. */
    public void tickExpiry() {
        long nowMs = System.currentTimeMillis();
        cooldowns.values().removeIf(t -> nowMs - t > 60_000L);
        if (!autoDisableExpired) {
            return;
        }
        boolean changed = false;
        for (RedeemCode c : codes.values()) {
            if (c.isEnabled() && !c.isInvalid() && isExpiredLive(c)) {
                c.setEnabled(false);
                c.setAutoDisabled(true);
                changed = true;
            }
        }
        if (changed) {
            save();
        }
    }
}
