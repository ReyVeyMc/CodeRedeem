package com.reyvey.coderedeem.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

/** Color helper: supports &a-style codes and &#RRGGBB hex. */
public final class ColorUtil {

    private static final LegacyComponentSerializer SERIALIZER =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private ColorUtil() {
    }

    public static Component color(String text) {
        return SERIALIZER.deserialize(text == null ? "" : text);
    }

    public static String serialize(Component component) {
        return SERIALIZER.serialize(component);
    }

    public static String strip(String text) {
        return PlainTextComponentSerializer.plainText().serialize(color(text));
    }
}
